README

	This game is written in Lua, using Lua player for the PSP, and will run on Windows, or a PSP with Lua Player installed.

AUTHORS

	Game Code was all written by me, Paul Whisler, except for the collision and animation functions.  All my code is in the game.lua file, and in the scipts folder except for the animLibDaaa.lua and collisionExample.lua files.

NEWS

	This is version 0.1, Level 2 has not yet been completed.

INSTALL

	To start the game in Windows, double click on the game.cmd file.  To move the player, use the arrow keys. To jump use the C key and to fire use the D key.

COPYRIGHT

	I did not create any of the art or audio.  The sprites, backgrounds and sounds were all found on various websites.  The mega man name and images all belong to Capcom, in which I am not affiliated in any way. This game is not intended for profit, I just made it for fun in my own time. Please don't sue me...   :)

BUGS

	I am still having some problems with collision on Level 1 screen 3 where you can fall through the holes, but it works well enough.




jumping doesn't work for level 2
should put in some enemies for level 2
should have a game over screen at the end of level 2 and restart game
